from mountain_car import *
import matplotlib.pyplot as plt
import numpy as np

class LinearPolicy(object):
    def __init__(self, num_states, num_actions, seed):
        self.num_states = num_states
        self.num_actions = num_actions

        # here are the weights for the policy - you may change this initialization
        #self.weights = np.zeros((self.num_states, self.num_actions))
        np.random.seed(seed)
        self.K = np.random.randn(2)
        self.sigma = 1

    # TODO: fill this function in
    # it should take in an environment state
    # return the action that follows the policy's distribution
    def act(self, state):
        mu= np.dot(state, self.K)
        action = np.random.normal(mu, self.sigma)
        return action

    # TODO: fill this function in
    # computes the gradient of the discounted return 
    # at a specific state and action
    # return the gradient, a (self.num_states, self.num_actions) numpy array
    def compute_gradient(self, state, action, discounted_return):
        log_grad = (action - np.dot(state, self.K)) / self.sigma**2 * state
        grad = discounted_return * log_grad
        return grad

    # TODO: fill this function in
    # takes a step of gradient ascent given a gradient (from compute_gradient())
    # and a step size. adjust self.weights
    def gradient_step(self, grad, step_size):
        self.K += step_size * grad

# TODO: fill this function in
# takes in a list of rewards from an episode
# and returns a list of discounted rewards
# Ex. get_discounted_returns([1, 1, 1], 0.5)
# should return [1.75, 1.5, 1]
def get_discounted_returns(rewards, gamma):
    T = len(rewards)
    discounted_returns = np.zeros(T)
    discounted_returns[-1] = rewards[-1]
    for i in reversed(range(T-1)):
        discounted_returns[i] = rewards[i] + gamma*discounted_returns[i+1]
    return discounted_returns

# TODO: fill this function in 
# this will take in an environment, GridWorld
# a policy (DiscreteSoftmaxPolicy)
# a discount rate, gamma
# and the number of episodes you want to run the algorithm for
def reinforce(env, policy, gamma, num_episodes, learning_rate):
    total_reward = np.zeros(num_episodes)

    for episode in range(num_episodes):
        states = []
        actions = []
        rewards = []
        state = env.reset()
        done = False
        rewardsum = 0
        steps = 0
        while not done:
            action = policy.act(state)
            actions.append(action)
            states.append(state)
            state, reward, done, _ = env.step([action])
            rewards.append(reward)
            rewardsum += reward
            steps+=1
            if(steps >= 10000):
                break
        discounted_returns = get_discounted_returns(rewards, gamma)
        for t in range(steps):
            grad = policy.compute_gradient(states[t], actions[t], discounted_returns[t])
            policy.gradient_step(grad, learning_rate)
        total_reward[episode] = rewardsum
    return total_reward


if __name__ == "__main__":
    gamma = 0.9
    num_episodes = 2000
    learning_rate = 1e-4
    env = Continuous_MountainCarEnv()
    policy = LinearPolicy(2, 1, 2)
    reinforce(env, policy, gamma, num_episodes, learning_rate)

    T = []
    for loop in range(5):
        policy = LinearPolicy(2, 1, loop)
        total_reward = reinforce(env, policy, gamma, num_episodes, learning_rate)     