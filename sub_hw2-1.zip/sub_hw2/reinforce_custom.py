from __future__ import print_function
from mountain_car import *
import numpy as np
import math
import random
import matplotlib.pyplot as plt

class DiscreteSoftmaxPolicy(object):
    def __init__(self):
        #predefined intervals of discretization
        self.pos_disc = np.linspace(-1.2, 0.6, num=5+1)
        self.vel_disc = np.linspace(-0.07, 0.07, num=10+1)
        self.act_disc = np.linspace(-1, 1, num=10+1)
        self.act_means = (self.act_disc[1:] + self.act_disc[:-1]) / 2

        self.num_pos = 5
        self.num_vel = 10
        self.num_act = 10
        self.weights = np.zeros([self.num_pos*self.num_vel, self.num_act])

    def softmax(self, x):
        ex = np.exp(x)
        sum_ex = np.sum(np.exp(x))
        return ex/sum_ex

    #finds discrete index representing a certain continuous state
    def find_discrete_state(self, state):
        discp = sum(state[0] > self.pos_disc[1:-1])
        discv = sum(state[1] > self.vel_disc[1:-1])
        return discp * self.num_vel + discv

    def find_discrete_action(self, action):
        return sum(action > self.act_disc[1:-1])

    def get_pi(self, st):
        logits = self.weights[st, : ]
        pi = self.softmax(logits)
        return pi

    def act(self, state):
        st = self.find_discrete_state(state)
        pi = self.get_pi(st)
        ac = np.random.choice(self.num_act, 1, p=pi)[0]
        action = self.act_means[ac]
        return action, ac

    def compute_gradient(self, state, action, discounted_return):
        st = self.find_discrete_state(state)
        ac = self.find_discrete_action(action)

        pi = self.get_pi(st)

        #make onehot array representing current action
        act_onehot = np.zeros(pi.shape)
        act_onehot[ac, ...] = 1.0

        #calculate grad(logpi)
        dsoftmax = pi * (act_onehot - pi)
        dlog = dsoftmax/pi
        w_grad = np.zeros((self.num_vel*self.num_pos, self.num_act))
        w_grad[st, :] = dlog * discounted_return
        return w_grad

    def gradient_step(self, grad, step_size):
        self.weights += step_size * grad

def get_discounted_returns(rewards, gamma):
    discounted_returns = []
    powers = np.arange(0, len(rewards))
    gammas = np.ones((powers.shape)) * gamma
    gamma_poly = np.power(gammas, powers)
    for i in range(len(rewards)):
        future_rewards = rewards[i:]
        future_gammas = []
        if(i > 0):
            future_gammas = gamma_poly[:-i]
        else:
            future_gammas = gamma_poly
        discounted_returns.append(np.sum(np.multiply(future_gammas, future_rewards)))
    return discounted_returns 

def reinforce(env, policy, gamma, num_episodes, learning_rate):
    total = []
    for episode in range(num_episodes):
        rewards = []
        states = []
        actions = []
        ep_reward = 0
        episode_length = 0
        state = env.reset()
        while(True):
            #pdb.set_trace()
            action, act = policy.act(state)
            n_state, reward, done, _= env.step([action])
            states.append(state)
            rewards.append(reward)
            ep_reward += reward
            actions.append(action)
            episode_length += 1
            state = n_state
            if(done or episode_length >= 999):
                break
        total.append(ep_reward)
        if(episode % 100 == 0):
            print(ep_reward)
        #pdb.set_trace()
        discounted_returns = get_discounted_returns(rewards, gamma)
        grad_v = np.zeros((policy.weights.shape))
        for step in range(episode_length):
            disc_ret = discounted_returns[step]
            s = states[step]
            a = actions[step]
            grad_v += policy.compute_gradient(s, a, disc_ret)
        policy.gradient_step(grad_v, learning_rate)
    return total

def get_num_states(self):
        return self.n_rows * self.n_cols



if __name__ == "__main__":
    gamma = 0.999
    num_episodes = 2000
    learning_rate = 1e-3
    env = Continuous_MountainCarEnv()
    policy = DiscreteSoftmaxPolicy()
    for loop in range(5):
        total_reward = reinforce(env, policy, gamma, num_episodes, learning_rate)
        print(total_reward)