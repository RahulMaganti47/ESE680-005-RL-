from grid_world import *
import pdb
import matplotlib.pyplot as plt
import numpy as np

class DiscreteSoftmaxPolicy(object):
    def __init__(self, num_states, num_actions, temperature):
        self.num_states = num_states
        self.num_actions = num_actions
        self.temperature = temperature

        # here are the weights for the policy
        self.weights = np.zeros((num_states, num_actions))

    def softmax(self, x):
        ex = np.exp(x)
        sum_ex = np.sum(np.exp(x))
        return ex/sum_ex

    def get_pi(self, state):
        logits = self.weights[state, : ]
        pi = self.softmax(logits)
        return pi

    # TODO: fill this function in
    # it should take in an environment state
    # return the action that follows the policy's distribution
    def act(self, state):
        pi = self.get_pi(state)
        action = np.random.choice(self.num_actions, p=pi)
        return action

    # TODO: fill this function in
    # computes the gradient of the discounted return 
    # at a specific state and action
    # return the gradient, a (self.num_states, self.num_actions) numpy array
    def compute_gradient(self, state, action, discounted_return):
        pi = self.get_pi(state)

        #make onehot array representing current action
        act_onehot = np.zeros(pi.shape)
        act_onehot[action, ...] = 1.0

        #calculate grad(logpi)
        dsoftmax = pi * (act_onehot - pi)
        dlog = dsoftmax/pi
        w_grad = np.zeros((self.num_states, self.num_actions))
        w_grad[state, :] = dlog * discounted_return
        return w_grad

    # TODO: fill this function in
    # takes a step of gradient ascent given a gradient (from compute_gradient())
    # and a step size. adjust self.weights
    def gradient_step(self, grad, step_size):
        self.weights += step_size * grad


# TODO: fill this function in
# takes in a list of rewards from an episode
# and returns a list of discounted rewards # Ex. get_discounted_returns([1, 1, 1], 0.5)
# should return [1.75, 1.5, 1]
def get_discounted_returns(rewards, gamma):
    discounted_returns = []
    powers = np.arange(0, len(rewards))
    gammas = np.ones((powers.shape)) * gamma
    gamma_poly = np.power(gammas, powers)
    for i in range(len(rewards)):
        future_rewards = rewards[i:]
        future_gammas = []
        if(i > 0):
            future_gammas = gamma_poly[:-i]
        else:
            future_gammas = gamma_poly
        discounted_returns.append(np.sum(np.multiply(future_gammas, future_rewards)))
    return discounted_returns

# TODO: fill this function in 
# this will take in an environment, GridWorld
# a policy (DiscreteSoftmaxPolicy)
# a discount rate, gamma
# and the number of episodes you want to run the algorithm for
def reinforce(env, policy, gamma, num_episodes, learning_rate):
    total = []
    for episode in range(num_episodes):
        rewards = []
        states = []
        actions = []
        ep_reward = 0
        episode_length = 0
        state = env.reset()
        while(True):
            #pdb.set_trace()
            action = policy.act(state)
            n_state, reward, done = env.step(action)
            states.append(state)
            rewards.append(reward)
            ep_reward += reward
            actions.append(action)
            episode_length += 1
            state = n_state
            if(done):
                break
        total.append(ep_reward)
        if(episode % 4 == 0):
            print(ep_reward)
        #pdb.set_trace()
        discounted_returns = get_discounted_returns(rewards, gamma)
        grad_v = np.zeros((policy.weights.shape))
        for step in range(episode_length):
            disc_ret = discounted_returns[step]
            s = states[step]
            a = actions[step]
            grad_v += policy.compute_gradient(s, a, disc_ret)
        policy.gradient_step(grad_v, learning_rate)
    return total

if __name__ == "__main__":
    np.random.seed(0)

    gamma = 0.9
    num_episodes = 20000
    learning_rate = 1e-4
    env = GridWorld(MAP2)

    policy = DiscreteSoftmaxPolicy(env.get_num_states(), env.get_num_actions(), temperature=1)
    total_reward = reinforce(env, policy, gamma, num_episodes, learning_rate)